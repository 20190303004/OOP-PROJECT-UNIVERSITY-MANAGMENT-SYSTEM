package pkg20190303004;

public class Main {

    public static void main(String[] args) {
        //I have created an object in process type and directed it into the menu.
        Process process = new Process();
        process.menu();
    }

}
