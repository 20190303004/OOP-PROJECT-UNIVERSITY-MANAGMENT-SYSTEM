package pkg20190303004;

/*
Since University included people in it, the people class implemented from University Interface Making also use of Inheritance
*/
public class People implements University {

    int income = 0, expenditure = 0;

    @Override
    public int totalIncome(int income) {
        this.income += income;
        return income;
    }

    @Override
    public int totalExpenditure(int expenditure) {
        this.expenditure = expenditure;
        return expenditure;
    }

}
