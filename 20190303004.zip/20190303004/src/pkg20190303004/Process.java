package pkg20190303004;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Process {

    Teachers t = new Teachers() {

        @Override
        public int totalIncome(int income) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public int totalExpenditure(int expenditure) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    };
    Students st = new Students() {
        @Override
        public int payment() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public int totalIncome(int income) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public int totalExpenditure(int expenditure) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    };
/*
    I have used ArrayList and HashSet from Generic Collections and defined them inside the constructor method
    */
    List<Teachers> teacherList;
    Set<Students> studentList;

    Process() {
        teacherList = new ArrayList<>();
        studentList = new HashSet<>();
    }

    int totalExpenditure;
    int totalIncome;

    public void addTeacher(String name, int a) {
        if (a == 1) {
            PartTimeTeachers pt = new PartTimeTeachers(name);
            teacherList.add(pt);
            totalExpenditure += pt.salary;
            System.out.println("Teacher is added.");
            System.out.println("----------------------------");
        } else if (a == 2) {
            FullTimeTeachers ft = new FullTimeTeachers(name);
            teacherList.add(ft);
            totalExpenditure += ft.salary;
            System.out.println("Teacher is added.");
            System.out.println("----------------------------");
        }
    }

    public void addStudent(String name, int a) {
        if (a == 1) {
            BachelorStudent bs = new BachelorStudent(name);
            studentList.add(bs);
            totalIncome += bs.payment;
            System.out.println("Student is added.");
            System.out.println("----------------------------");
        } else if (a == 2) {
            MasterStudent ms = new MasterStudent(name);
            studentList.add(ms);
            totalIncome += ms.payment;
            System.out.println("Student is added.");
            System.out.println("----------------------------");
        }
    }

    public void deleteTeacher(String name) {

        for (int i = 0; i < teacherList.size(); i++) {
            if (teacherList.get(i).name.equals(name)) {
                totalExpenditure-=teacherList.get(i).salary();
                teacherList.remove(i);
                System.out.println("Teacher is deleted.");
                System.out.println("----------------------------");
                break;
            } else if (i == teacherList.size() - 1){
                System.out.println("Teacher doesn't exist in the list.");
                System.out.println("----------------------------");
                break;
            }
        }

    }

    public void deleteStudent(String name) {

        Students array[] = studentList.toArray(new Students[studentList.size()]);

        for (int i = 0; i < array.length; i++) {
            if (array[i].name.equals(name)) {
                totalIncome-=array[i].payment();
                studentList.remove(array[i]);
                System.out.println("Student is deleted.");
                System.out.println("----------------------------");
                break;

            } else if (i == array.length - 1) { 
                System.out.println("Student doesn't exist.");
                System.out.println("----------------------------");
            }
        }
    }

    public void showTeacherList() {
        for (int i = 0; i < teacherList.size(); i++) {
            System.out.println("Teacher name: " + teacherList.get(i).name + "\t Teacher salary: " + teacherList.get(i).salary());
        }
        System.out.println("----------------------------");
    }

    public void showStudentList() {
        Students array[] = studentList.toArray(new Students[studentList.size()]);
        for (int i = 0; i < array.length; i++) {
            System.out.println("Student name: " + array[i].name + "\t Student payment: " + array[i].payment());
        }
        System.out.println("----------------------------");
    }

    public int income() {
        return totalIncome;
    }

    public int expenditure() {
        return totalExpenditure;
    }

    public int showBalance() {
        int profit = income() - expenditure();
        System.out.println("****************************");
        System.out.println("Total Income: " + income());
        System.out.println("Total Expenditure: " + expenditure());
        System.out.println("Total Profit: " + profit);
        System.out.println("****************************");
        return profit;
    }

    public void menu() {
        while (true) {
            System.out.println("Please Choose what you want to do:");
            System.out.println("1)Add Teacher into system.");
            System.out.println("2)Add Student into system.");
            System.out.println("3)Delete Teacher from system.");
            System.out.println("4)Delete Student from system.");
            System.out.println("5)Show profit state of university.");
            System.out.println("6)Show teachers list.");
            System.out.println("7)Show students list.");
            System.out.println("8)Exit.");

            Scanner scanner = new Scanner(System.in);
            int choose;
            while (true) {
                System.out.print("Choose: ");
                choose = scanner.nextInt();
                System.out.println("");
                if (choose < 1 || choose > 8) {
                    System.out.println("Please choose an available option.");
                } else {
                    break;
                }
            }
            if (choose == 1) {
                String name;
                int position;
                System.out.print("Please write the name of the Teacher: ");
                name = scanner.next();
                System.out.println("");
                System.out.print("Please choose teacher's position(1: Part time, 2: Full time): ");

                while (true) {
                    position = scanner.nextInt();
                    if (position != 1 && position != 2) {
                        System.out.println("Please choose an available option.");
                    } else {
                        break;
                    }
                }
                System.out.println("");
                addTeacher(name, position);
            } else if (choose == 2) {
                String name;
                int position;
                System.out.print("Please write the name of the Student: ");
                name = scanner.next();
                System.out.println("");
                System.out.print("Please choose student's position(1: Bachelor's Degree , 2: Master's Degree): ");

                while (true) {
                    position = scanner.nextInt();
                    if (position != 1 && position != 2) {
                        System.out.println("Please choose an available option.");
                    } else {
                        break;
                    }
                }
                System.out.println("");
                addStudent(name, position);
            } else if (choose == 3) {
                System.out.print("Please write the name of the teacher that you want to delete: ");
                String name = scanner.next();
                deleteTeacher(name);
            } else if (choose == 4) {
                System.out.print("Please write the name of the student that you want to delete: ");
                String name = scanner.next();
                deleteStudent(name);
            } else if (choose == 5) {
                showBalance();
            } else if (choose == 6) {
                showTeacherList();
            } else if (choose == 7) {
                showStudentList();
            } else {
                break;
            }
        }
    }

}
