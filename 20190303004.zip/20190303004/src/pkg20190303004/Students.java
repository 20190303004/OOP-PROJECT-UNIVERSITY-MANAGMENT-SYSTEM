package pkg20190303004;
/*
Just Like Teachers class, students are also human so they are inherited from the people class. And just like teachers class
we have two types of students making different types of payments allowing us to use polymorphism again.
*/
public class Students extends People {
    String name="";
    public int payment(){
        return 0;
    }
    
}

class BachelorStudent extends Students {
    int payment;
    
    BachelorStudent(String name){
        this.name=name;
        payment();
    }
    
    @Override
    public int payment(){
        this.payment=10000;
        return 10000;
    }

}

class MasterStudent extends Students {
    int payment;
    
    MasterStudent(String name){
        this.name=name;
        payment();
    }
    
    @Override
    public int payment(){
        this.payment=15000;
        return 15000;
    }

}
