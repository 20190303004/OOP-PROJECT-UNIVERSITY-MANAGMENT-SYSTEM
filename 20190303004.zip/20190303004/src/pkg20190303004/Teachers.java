package pkg20190303004;
/*
I have inherited teachers from people because teachers are included in people. Using Imheritance again.
*/
public class Teachers extends People {
    String name="";
    public Teachers() {
    }

    public int salary(){
        return 0;
    }
}
/*
Since PartTimeTeachers and FullTimeTeachers are included in teachers class, we have extended them from teachers class by inheritance. Since the functions that are used in these classes
are different from each other we have used polymorphism. For example salary function returns 6000 units for full time and 3000 units for part time teachers.
*/
class PartTimeTeachers extends Teachers {

    int salary;

    PartTimeTeachers(String name) {
        this.name = name;
        salary();
    }

    @Override
    public int salary() {
        salary = 3000;
        return salary;
    }
}

class FullTimeTeachers extends Teachers {

    int salary;

    FullTimeTeachers(String name) {
        this.name = name;
        salary();
    }

    @Override
    public int salary() {
        salary = 6000;
        return salary;
    }

}
