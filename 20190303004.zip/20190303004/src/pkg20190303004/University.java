package pkg20190303004;

//Interface as University and its functions are created
public interface University {
    public int totalIncome(int income);
    public int totalExpenditure(int expenditure);
}


